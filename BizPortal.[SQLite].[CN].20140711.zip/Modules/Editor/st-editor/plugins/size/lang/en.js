﻿STEditor.Lang["en"]["h_command"] = 'set text font-size';
STEditor.Lang["en"]["PleaseInputFontSize"] = 'please input the font size';