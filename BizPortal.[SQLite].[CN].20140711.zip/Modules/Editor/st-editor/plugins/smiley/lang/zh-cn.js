﻿STEditor.Lang["zh-cn"]["smiley_command"] = '选择表情';
STEditor.Lang["zh-cn"]["SmileyPicker"] = '表情帖图';