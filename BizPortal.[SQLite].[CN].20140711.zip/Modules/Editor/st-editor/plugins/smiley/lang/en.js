﻿STEditor.Lang["en"]["smiley_command"] = 'pick smiley';
STEditor.Lang["en"]["SmileyPicker"] = 'Smiley Picker';