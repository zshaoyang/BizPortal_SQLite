﻿STEditor.Lang["zh-cn"]["h_command"] = '设置标题格式';
STEditor.Lang["zh-cn"]["HeaderFormat"] = '标题格式';
STEditor.Lang["zh-cn"]["PleaseSelectHeaderFormat"] = '请选择标题格式';