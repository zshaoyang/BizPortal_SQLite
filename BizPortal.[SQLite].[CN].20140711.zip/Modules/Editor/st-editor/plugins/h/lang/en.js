﻿STEditor.Lang["en"]["h_command"] = 'set text header format';
STEditor.Lang["en"]["HeaderFormat"] = 'Header Format';
STEditor.Lang["en"]["PleaseSelectHeaderFormat"] = 'please select the header format';