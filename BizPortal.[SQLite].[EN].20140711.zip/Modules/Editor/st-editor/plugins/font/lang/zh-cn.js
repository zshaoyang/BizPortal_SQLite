﻿STEditor.Lang["zh-cn"]["font_command"] = '设置字体';
STEditor.Lang["zh-cn"]["PleaseInputFontFamily"] = '请输入字体名称';