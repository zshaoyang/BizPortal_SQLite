﻿STEditor.Lang["zh-cn"]["size_command"] = '设置字大小';
STEditor.Lang["zh-cn"]["PleaseInputFontSize"] = '请输入字体大小';