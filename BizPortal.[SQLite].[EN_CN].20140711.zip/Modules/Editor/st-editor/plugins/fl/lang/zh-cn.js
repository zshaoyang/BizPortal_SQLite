﻿STEditor.Lang["zh-cn"]["fl_command"] = '插入flash媒体';
STEditor.Lang["zh-cn"]["PleaseInputFlashUrl"] = '请输入flash媒体地址';