﻿STEditor.Lang["en"]["fl_command"] = 'insert flash media';
STEditor.Lang["en"]["PleaseInputFlashUrl"] = 'please input the flash media url';