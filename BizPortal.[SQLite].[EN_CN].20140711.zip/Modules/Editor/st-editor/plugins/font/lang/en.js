﻿STEditor.Lang["en"]["font_command"] = 'set text font-family';
STEditor.Lang["en"]["PleaseInputFontFamily"] = 'please input the font family';